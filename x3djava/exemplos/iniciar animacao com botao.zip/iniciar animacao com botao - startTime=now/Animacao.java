

// External imports
import java.awt.*;
import java.util.*;
import javax.swing.*;
import org.web3d.x3d.sai.*;


public class Animacao extends JFrame implements X3DFieldEventListener {

  // ----------------- ACESSO X3D ------------------------------------------------------------------------
     
    
    X3DNode mat;
    X3DScene mainScene;
    
     X3DNode animacao_bola;
     X3DNode relogio_animacao;
     SFBool loop_anim;
     
     SFTime startTime_animacao;
      float tp;
    
    public Animacao() {
        
        initComponents();
         setDefaultCloseOperation(EXIT_ON_CLOSE);
        Container contentPane = getContentPane();

        // Setup browser parameters
        HashMap requestedParameters = new HashMap();

        // Create an SAI component
        X3DComponent x3dComp = BrowserFactory.createX3DComponent(requestedParameters);

        // Add the component to the UI
        JComponent x3dPanel = (JComponent)x3dComp.getImplementation();
        contentPane.add(x3dPanel, BorderLayout.CENTER);

        // Get an external browser
        ExternalBrowser x3dBrowser = x3dComp.getBrowser();

        setSize(600,500);
        show();
        
          // Create an X3D scene by loading a file
        mainScene = x3dBrowser.createX3DFromURL(new String[] { "bola.x3d" });

        // Replace the current world with the new one
        x3dBrowser.replaceWorld(mainScene);
        
         relogio_animacao= mainScene.getNamedNode("Wizard");
         startTime_animacao = (SFTime) relogio_animacao.getField("startTime");
         

         
         
            
    }
    
    
     public void readableFieldChanged(org.web3d.x3d.sai.X3DFieldEvent x3DFieldEvent) {
         
         
          
    }
    
     
      // ----------------- CLICAR ------------------------------------------------------------------------
 
     private void Clicar(java.awt.event.MouseEvent evt)  {
         
        
       System.out.println("  ");
       System.out.println(" --------- animacao bola  ------ ");
     
       double tempo= new Date().getTime() / 1000;
       startTime_animacao.setValue(tempo);
          
                  
                 
    }
     
   
    
  // ----------------- COMPONENTS ------------------------------------------------------------------------
    
 private void initComponents() {
        button1 = new java.awt.Button();
        textField1 = new java.awt.TextField();
        
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                exitForm(evt);
            }
        });
        
        button1.setLabel("button1");
        
        button1.setLabel("button1");
        button1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                
                                
                Clicar(evt);
            }
        });
        
        getContentPane().add(button1, java.awt.BorderLayout.CENTER);
        
        textField1.setText("");
        getContentPane().add(textField1, java.awt.BorderLayout.NORTH);
        
        pack();
    }
    
 
 
 
 // ----------------- exit ------------------------------------------------------------------------
        private void exitForm(java.awt.event.WindowEvent evt) {
        System.exit(0);
        }
    
 // ----------------- MAIN ------------------------------------------------------------------------
        
    public static void main(String[] args) {
       // new Visual().show();
       
        Animacao demo = new Animacao();
       
        
    }
    
   
// ----------------- variaveis componentes ------------------------------------------------------------------------
      private java.awt.Button button1;
      private java.awt.TextField textField1;

}
