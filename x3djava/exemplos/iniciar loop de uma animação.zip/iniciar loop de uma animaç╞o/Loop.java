

// External imports
import java.awt.*;
import java.util.HashMap;
import javax.swing.*;
import org.web3d.x3d.sai.*;


public class Loop extends JFrame implements X3DFieldEventListener {

  // ----------------- ACESSO X3D ------------------------------------------------------------------------
     
    
    X3DNode mat;
    X3DScene mainScene;
    
     X3DNode animacao_bola;
     X3DNode relogio_animacao;
     SFBool loop_anim;
    
    public Loop() {
        
        initComponents();
         setDefaultCloseOperation(EXIT_ON_CLOSE);
        Container contentPane = getContentPane();

        // Setup browser parameters
        HashMap requestedParameters = new HashMap();

        // Create an SAI component
        X3DComponent x3dComp = BrowserFactory.createX3DComponent(requestedParameters);

        // Add the component to the UI
        JComponent x3dPanel = (JComponent)x3dComp.getImplementation();
        contentPane.add(x3dPanel, BorderLayout.CENTER);

        // Get an external browser
        ExternalBrowser x3dBrowser = x3dComp.getBrowser();

        setSize(600,500);
        show();
        
          // Create an X3D scene by loading a file
        mainScene = x3dBrowser.createX3DFromURL(new String[] { "bola.x3d" });

        // Replace the current world with the new one
        x3dBrowser.replaceWorld(mainScene);
        
         relogio_animacao= mainScene.getNamedNode("vizx_init");
         SFTime tempo_ciclo = (SFTime) relogio_animacao.getField("cycleTime");
         tempo_ciclo.addX3DEventListener(this);

         
         
         //relogio do inicio da animacao
          animacao_bola= mainScene.getNamedNode("vizx_init");
          loop_anim = (SFBool) animacao_bola.getField("loop");
            
    }
    
    
     public void readableFieldChanged(org.web3d.x3d.sai.X3DFieldEvent x3DFieldEvent) {
         
         System.out.println(" ");
          System.out.println(" --------- inicio da anim cicletime --- loop = false ");
          System.out.println(" ");
          
          
         
          loop_anim.setValue(false);
          
    }
    
     
      // ----------------- CLICAR ------------------------------------------------------------------------
 
     private void Clicar(java.awt.event.MouseEvent evt)  {
         
        
       System.out.println("  ");
          System.out.println(" --------- animacao bola  loop = true------ ");
     
          loop_anim.setValue(true);
          
                 
    }
     
   
    
  // ----------------- COMPONENTS ------------------------------------------------------------------------
    
 private void initComponents() {
        button1 = new java.awt.Button();
        textField1 = new java.awt.TextField();
        
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                exitForm(evt);
            }
        });
        
        button1.setLabel("button1");
        
        button1.setLabel("button1");
        button1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                
                                
                Clicar(evt);
            }
        });
        
        getContentPane().add(button1, java.awt.BorderLayout.CENTER);
        
        textField1.setText("");
        getContentPane().add(textField1, java.awt.BorderLayout.NORTH);
        
        pack();
    }
    
 
 
 
 // ----------------- exit ------------------------------------------------------------------------
        private void exitForm(java.awt.event.WindowEvent evt) {
        System.exit(0);
        }
    
 // ----------------- MAIN ------------------------------------------------------------------------
        
    public static void main(String[] args) {
       // new Visual().show();
       
        Loop demo = new Loop();
       
        
    }
    
   
// ----------------- variaveis componentes ------------------------------------------------------------------------
      private java.awt.Button button1;
      private java.awt.TextField textField1;

}
