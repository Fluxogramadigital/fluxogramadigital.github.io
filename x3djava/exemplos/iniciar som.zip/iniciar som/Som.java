

// External imports
import java.awt.*;
import java.util.HashMap;
import javax.swing.*;
import org.web3d.x3d.sai.*;


public class Som extends JFrame implements X3DFieldEventListener {

  // ----------------- ACESSO X3D ------------------------------------------------------------------------
  
    X3DScene mainScene;
    X3DNode som;
    
    public Som() {
        
        initComponents();
         setDefaultCloseOperation(EXIT_ON_CLOSE);
        Container contentPane = getContentPane();

        // Setup browser parameters
        HashMap requestedParameters = new HashMap();

        // Create an SAI component
        X3DComponent x3dComp = BrowserFactory.createX3DComponent(requestedParameters);

        // Add the component to the UI
        JComponent x3dPanel = (JComponent)x3dComp.getImplementation();
        contentPane.add(x3dPanel, BorderLayout.CENTER);

        // Get an external browser
        ExternalBrowser x3dBrowser = x3dComp.getBrowser();

        setSize(600,500);
        show();
        
          // Create an X3D scene by loading a file
        mainScene = x3dBrowser.createX3DFromURL(new String[] { "som.x3d" });

        // Replace the current world with the new one
        x3dBrowser.replaceWorld(mainScene);
        
    
      
      
            
    }
    
     public void readableFieldChanged(org.web3d.x3d.sai.X3DFieldEvent x3DFieldEvent) {
         
         
          System.out.println(" --------- SOM ACABOU ------ ");
         
    }
    
   
    
    
  // ----------------- COMPONENTS ------------------------------------------------------------------------
    
 private void initComponents() {
        button1 = new java.awt.Button();
        textField1 = new java.awt.TextField();
        
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                exitForm(evt);
            }
        });
        
        button1.setLabel("button1");
        
        button1.setLabel("button1");
        button1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                
                                
                Clicar(evt);
            }
        });
        
        getContentPane().add(button1, java.awt.BorderLayout.CENTER);
        
        textField1.setText("");
        getContentPane().add(textField1, java.awt.BorderLayout.NORTH);
        
        pack();
    }
    
  // ----------------- CLICAR ------------------------------------------------------------------------
 
     private void Clicar(java.awt.event.MouseEvent evt)  {
         
       
       System.out.println("  ");
          System.out.println(" --------- parar loop e som ------ ");
        
          som= mainScene.getNamedNode("AClip_Sound2");
          
          if (som == null) {
            System.out.println("Couldn't find material named: AClip_Sound2");
            return;
        }
          
          SFBool loop_som = (SFBool) som.getField("loop");
          loop_som.setValue(true); 
          
          SFTime starttime_som = (SFTime) som.getField("startTime");
          starttime_som.setValue(1); 
          
         
    }
 
 
 // ----------------- exit ------------------------------------------------------------------------
        private void exitForm(java.awt.event.WindowEvent evt) {
        System.exit(0);
        }
    
 // ----------------- MAIN ------------------------------------------------------------------------
        
    public static void main(String[] args) {
       // new Visual().show();
       
        Som demo = new Som();
       
        
    }
    
   
    
// ----------------- variaveis componentes ------------------------------------------------------------------------
      private java.awt.Button button1;
      private java.awt.TextField textField1;

}
