

// External imports
import java.awt.*;
import java.util.HashMap;
import javax.swing.*;
import org.web3d.x3d.sai.*;


public class Proximidade extends JFrame implements X3DFieldEventListener {

  // ----------------- ACESSO X3D ------------------------------------------------------------------------
     
    float[] blue = {1,1,1};
    SFColor color;
    X3DNode mat;
    X3DScene mainScene;
    
    SFTime EnterT;
    
    
    public Proximidade() {
        
        initComponents();
         setDefaultCloseOperation(EXIT_ON_CLOSE);
        Container contentPane = getContentPane();

        // Setup browser parameters
        HashMap requestedParameters = new HashMap();

        // Create an SAI component
        X3DComponent x3dComp = BrowserFactory.createX3DComponent(requestedParameters);

        // Add the component to the UI
        JComponent x3dPanel = (JComponent)x3dComp.getImplementation();
        contentPane.add(x3dPanel, BorderLayout.CENTER);

        // Get an external browser
        ExternalBrowser x3dBrowser = x3dComp.getBrowser();

        setSize(600,500);
        show();
        
          // Create an X3D scene by loading a file
        mainScene = x3dBrowser.createX3DFromURL(new String[] { "sensor_vr.x3d" });

        // Replace the current world with the new one
        x3dBrowser.replaceWorld(mainScene);

        
        mat = mainScene.getNamedNode("material0_mat");
        if (mat == null) {
            System.out.println("Couldn't find material named: material0_mat");
            return;
        }

       
       
       
        
         //------------------ is active proximity sensor --------------------------------------  
        X3DNode ProximidadeX3D = mainScene.getNamedNode("Sensor1");
        SFBool Proximidade = (SFBool) ProximidadeX3D.getField("isActive");
        Proximidade.addX3DEventListener(this);
        
        
        //------------ touch time ------------------------------
        
        X3DNode touch = mainScene.getNamedNode("Sensor2");
        SFTime ttime = (SFTime) touch.getField("touchTime");

        ttime.addX3DEventListener(this);
        
         //------  colision ------------------------------------
        
        X3DNode colisao = mainScene.getNamedNode("cilind");
        SFTime tcolisao = (SFTime) colisao.getField("collideTime");
        tcolisao.addX3DEventListener(this);
        
                     
    }
    
    //--------------------------------------------------------------------------------------------------    
    public void readableFieldChanged(org.web3d.x3d.sai.X3DFieldEvent x3DFieldEvent) {
        
        System.out.println("  ");
        
        System.out.println("ESTAMOS DENTRO DA AREA");
        textField1.setText("Cor mudada");
        
        mat = mainScene.getNamedNode("material0_mat");
        color = (SFColor) mat.getField("diffuseColor");
        float[]blue = {0,0,1};
        color.setValue(blue);
    }
    
   
    
    
  // ----------------- COMPONENTS ------------------------------------------------------------------------
    
 private void initComponents() {
        button1 = new java.awt.Button();
        textField1 = new java.awt.TextField();
        
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                exitForm(evt);
            }
        });
        
        button1.setLabel("button1");
        
        button1.setLabel("button1");
        button1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                
                                
                Clicar(evt);
            }
        });
        
        getContentPane().add(button1, java.awt.BorderLayout.CENTER);
        
        textField1.setText("");
        getContentPane().add(textField1, java.awt.BorderLayout.NORTH);
        
        pack();
    }
    
  // ----------------- CLICAR ------------------------------------------------------------------------
 
     private void Clicar(java.awt.event.MouseEvent evt)  {
         
       
         
        textField1.setText("Cor mudada");
        
        mat = mainScene.getNamedNode("material0_mat");
        color = (SFColor) mat.getField("diffuseColor");
        float[]blue = {0,0,1};
        color.setValue(blue);
    }
 
 
 // ----------------- exit ------------------------------------------------------------------------
        private void exitForm(java.awt.event.WindowEvent evt) {
        System.exit(0);
        }
    
 // ----------------- MAIN ------------------------------------------------------------------------
        
    public static void main(String[] args) {
       // new Visual().show();
       
        Proximidade demo = new Proximidade();
       
        
    }

    
// ----------------- variaveis componentes ------------------------------------------------------------------------
      private java.awt.Button button1;
      private java.awt.TextField textField1;

}
