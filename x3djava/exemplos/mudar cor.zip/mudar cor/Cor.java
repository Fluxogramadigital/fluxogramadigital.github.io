

// External imports
import java.awt.*;
import java.util.HashMap;
import javax.swing.*;
import org.web3d.x3d.sai.*;


public class Cor extends JFrame {

  // ----------------- ACESSO X3D ------------------------------------------------------------------------
     
    float[] blue = {1,1,1};
    SFColor color;
    X3DNode mat;
    X3DScene mainScene;
    
    public Cor() {
        
        initComponents();
         setDefaultCloseOperation(EXIT_ON_CLOSE);
        Container contentPane = getContentPane();

        // Setup browser parameters
        HashMap requestedParameters = new HashMap();

        // Create an SAI component
        X3DComponent x3dComp = BrowserFactory.createX3DComponent(requestedParameters);

        // Add the component to the UI
        JComponent x3dPanel = (JComponent)x3dComp.getImplementation();
        contentPane.add(x3dPanel, BorderLayout.CENTER);

        // Get an external browser
        ExternalBrowser x3dBrowser = x3dComp.getBrowser();

        setSize(600,500);
        show();
        
          // Create an X3D scene by loading a file
        mainScene = x3dBrowser.createX3DFromURL(new String[] { "bola vermelha.x3d" });

        // Replace the current world with the new one
        x3dBrowser.replaceWorld(mainScene);

       
       

        
            
    }
    
   
    
    
  // ----------------- COMPONENTS ------------------------------------------------------------------------
    
 private void initComponents() {
        button1 = new java.awt.Button();
        textField1 = new java.awt.TextField();
        
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                exitForm(evt);
            }
        });
        
        button1.setLabel("button1");
        
        button1.setLabel("button1");
        button1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                
                                
                Clicar(evt);
            }
        });
        
        getContentPane().add(button1, java.awt.BorderLayout.CENTER);
        
        textField1.setText("");
        getContentPane().add(textField1, java.awt.BorderLayout.NORTH);
        
        pack();
    }
    
  // ----------------- CLICAR ------------------------------------------------------------------------
 
     private void Clicar(java.awt.event.MouseEvent evt)  {
         
       
         
        textField1.setText("Cor mudada");
        
        mat = mainScene.getNamedNode("Red_mat");
        if (mat == null) {
            System.out.println("Couldn't find material named: esfera");
            return;
        }
        color = (SFColor) mat.getField("diffuseColor");
        float[]blue = {0,0,1};
        color.setValue(blue);
    }
 
 
 // ----------------- exit ------------------------------------------------------------------------
        private void exitForm(java.awt.event.WindowEvent evt) {
        System.exit(0);
        }
    
 // ----------------- MAIN ------------------------------------------------------------------------
        
    public static void main(String[] args) {
       // new Visual().show();
       
        Cor demo = new Cor();
       
        
    }
    
// ----------------- variaveis componentes ------------------------------------------------------------------------
      private java.awt.Button button1;
      private java.awt.TextField textField1;

}
